from fastapi import FastAPI
from datetime import datetime
import uuid

app = FastAPI()
from pydantic import BaseModel
from fastapi import HTTPException

class TagIn(BaseModel):
    tag: str
class Tag(TagIn):
    created: datetime
    secret: str

class TagOut(BaseModel):
    tag: str
    created: datetime


import datetime
tag_store: dict[str, Tag] = {}
@app.post('/')
def create(tag_in: TagIn) -> TagIn:
    tag = Tag(
        tag=tag_in.tag,
        created=datetime.utcnow(),
        secret=str(uuid.uuid4())  # generate unique secret
    )
    tag_store[tag.tag] = tag
    return tag  # TagOut is enforced by response_model


@app.get("/{tag_str}", response_model=TagOut)
def get_one(tag_str: str) -> TagOut:
    tag = tag_store.get(tag_str)
    if not tag:
        raise HTTPException(status_code=404, detail="Tag not found")
    return tag